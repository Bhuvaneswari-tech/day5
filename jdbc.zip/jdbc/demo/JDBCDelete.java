package jdbc.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class JDBCDelete {

	public static void main(String[] args) {
		String url      = "jdbc:mysql://localhost:3306/testdb";
        String user     = "root";
        String password = "root";

        String sql = "DELETE FROM students WHERE id = ?";

        try (
            Connection conn = DriverManager.getConnection(url, user, password);
            PreparedStatement stmt = conn.prepareStatement(sql);
        ) {
            // Set the id of the record to delete
            stmt.setInt(1, 101);

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                System.out.println("✅ Student deleted successfully.");
            } else {
                System.out.println("⚠️ No student found with id=101.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

	}

}
