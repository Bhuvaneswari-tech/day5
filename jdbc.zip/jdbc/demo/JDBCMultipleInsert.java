package jdbc.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class JDBCMultipleInsert {

	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/testdb";
		String user = "root";
		String password = "root"; //instead of root please provide your own password
		
		String[][] studentData = {
				{"102", "Alice", "92"},
			    {"103", "Bob", "78"},
			    {"104", "Eve", "88"},
			    {"105", "Charles", "89"}
		};
		
		try {
			
			//Load JDBC Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Establish Connection
			Connection conn = DriverManager.getConnection(url,user,password);
			
			String sql = "INSERT INTO students (id, name, marks) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            for(String[] stud: studentData) {
            	stmt.setInt(1,Integer.parseInt(stud[0]));
            	stmt.setString(2,stud[1]);
            	stmt.setInt(3, Integer.parseInt(stud[2]));
            	stmt.executeUpdate();
            }
            
            System.out.println("All students inserted successfully.");
			//System.out.println("Connected to the database.");
            
            //Set Parameters
//            stmt.setInt(1, 101);
//            stmt.setString(2, "John");
//            stmt.setInt(3, 86);
            
//            int rowsInserted = stmt.executeUpdate();
            
//            if(rowsInserted>0) {
//            	System.out.println("Student inserted succesfully.");
//            }
            
            stmt.close();
			conn.close();
		}
		catch(Exception e) {
			System.out.println("Connection Error: " + e);
		}


	}

}
