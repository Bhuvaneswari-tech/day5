package jdbc.demo;

import java.sql.Connection;
import java.sql.DriverManager;

public class JDBCConnection {

	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/testdb";
		String user = "root";
		String password = "root"; //instead of root please provide your own password
		
		try {
			
			//Load JDBC Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Establish Connection
			Connection conn = DriverManager.getConnection(url,user,password);
			System.out.println("Connected to the database.");
			conn.close();
		}
		catch(Exception e) {
			System.out.println("Connection Error: " + e);
		}
	}

}


//Project name: JDBCExample

//Package Name: jdbc.demo

//Class Name: JDBCConnection