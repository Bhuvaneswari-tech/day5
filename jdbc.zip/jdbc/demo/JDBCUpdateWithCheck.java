package jdbc.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class JDBCUpdateWithCheck {

	public static void main(String[] args) {
		 String url      = "jdbc:mysql://localhost:3306/testdb";
	        String user     = "root";
	        String password = "root";

	        Scanner sc = new Scanner(System.in);

	        System.out.print("Enter Student ID to update: ");
	        int id = sc.nextInt();
	        sc.nextLine(); // consume newline

	        try (
	            Connection conn = DriverManager.getConnection(url, user, password);
	        ) {
	            // Step 1: Check if ID exists
	            String checkSql = "SELECT * FROM students WHERE id = ?";
	            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
	            checkStmt.setInt(1, id);
	            ResultSet rs = checkStmt.executeQuery();

	            if (!rs.next()) {
	                System.out.println("❌ Record not found for ID = " + id);
	            } else {
	                // Step 2: If exists, take name and marks
	                System.out.print("Enter New Name: ");
	                String name = sc.nextLine();

	                System.out.print("Enter New Marks: ");
	                int marks = sc.nextInt();

	                // Step 3: Update the record
	                String updateSql = "UPDATE students SET name = ?, marks = ? WHERE id = ?";
	                PreparedStatement updateStmt = conn.prepareStatement(updateSql);
	                updateStmt.setString(1, name);
	                updateStmt.setInt(2, marks);
	                updateStmt.setInt(3, id);

	                int rows = updateStmt.executeUpdate();

	                if (rows > 0) {
	                    System.out.println("✅ Student record updated successfully.");
	                }

	                updateStmt.close();
	            }

	            rs.close();
	            checkStmt.close();

	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        sc.close();

	}

}
