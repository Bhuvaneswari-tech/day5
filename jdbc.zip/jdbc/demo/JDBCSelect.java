package jdbc.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JDBCSelect {

	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/testdb";
		String user = "root";
		String password = "root"; //instead of root please provide your own password
		
		try {
			
			//Load JDBC Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Establish Connection
			Connection conn = DriverManager.getConnection(url,user,password);
			
			//Create Statement Object
			Statement stmt = conn.createStatement();
			
			//Execute Select Query
			String sql = "SELECT * FROM students";
			ResultSet rs = stmt.executeQuery(sql);
			
			//Process the ResultSet
			System.out.println("ID\tName\t\tMark");
			System.out.println("-------------------------------------");
			while(rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				int mark = rs.getInt("marks");
				
				System.out.println(id + "\t" + name + "\t\t" + mark);
			}
			
			rs.close();
			stmt.close();
			//System.out.println("Connected to the database.");
			conn.close();
		}
		catch(Exception e) {
			System.out.println("Connection Error: " + e);
		}

	}

}
