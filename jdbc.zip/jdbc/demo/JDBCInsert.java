package jdbc.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class JDBCInsert {

	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/testdb";
		String user = "root";
		String password = "root"; //instead of root please provide your own password
		
		try {
			
			//Load JDBC Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//Establish Connection
			Connection conn = DriverManager.getConnection(url,user,password);
			
			String sql = "INSERT INTO students (id, name, marks) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
			//System.out.println("Connected to the database.");
            
            //Set Parameters
            stmt.setInt(1, 101);
            stmt.setString(2, "John");
            stmt.setInt(3, 86);
            
            int rowsInserted = stmt.executeUpdate();
            
            if(rowsInserted>0) {
            	System.out.println("Student inserted succesfully.");
            }
            
            stmt.close();
			conn.close();
		}
		catch(Exception e) {
			System.out.println("Connection Error: " + e);
		}

	}

}
