package Java8;

import java.util.Arrays;
import java.util.List;

public class MethodRefExample {

	public static void main(String[] args) {
		List<String> empList = Arrays.asList("Alice", "Bob", "Charlie");
		
		
		System.out.println("Lambda Expression: ");
		empList.forEach(name -> System.out.println(name)); //using Lambda Expression
		
		System.out.println("\nMethod Reference");
		empList.forEach(System.out::println);
	}

}
