package Java8;

@FunctionalInterface
public interface myFunction {
	void doSomething();
}
