package Java8;

public class FunctionalMain {

	public static void main(String[] args) {
		myFunction f = () -> System.out.println("Doing Something...");
		f.doSomething();

	}

}

/*
 public class Example1 implements Person{
 	@Override
 	public void add(int a, int b){
 	System.out.pritln(a+b);
 	}
 } 
 */
