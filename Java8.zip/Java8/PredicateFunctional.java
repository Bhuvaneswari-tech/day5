package Java8;

import java.util.function.Predicate;

public class PredicateFunctional {

	public static void main(String[] args) {
		Predicate<String> input = s-> s.length() >5;
		System.out.println(input.test("Hello"));       //false
		System.out.println(input.test("welcome"));     //true

	}

}


/*
 Predicate interface will return boolean values
 usage - for testing and filtering 
 built-in method - test
 */
