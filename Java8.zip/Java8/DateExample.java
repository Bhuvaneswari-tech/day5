package Java8;

import java.time.LocalDate;
import java.time.Period;

public class DateExample {

	public static void main(String[] args) {
		LocalDate joiningDate = LocalDate.of(2025,1,15);
		LocalDate currentDate = LocalDate.now();
		
		Period period = Period.between(joiningDate, currentDate);
		
		//System.out.println("Years of Service: " + period.getYears());
		System.out.println("Years of Service: " + period.getYears());
        System.out.println("Months of Service: " + period.getMonths());
        System.out.println("Days of Service: " + period.getDays());
	}

}


//Use Case: Display employee's joining data and calculate during of employment'